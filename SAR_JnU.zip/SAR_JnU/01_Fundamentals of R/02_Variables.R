# Variables (Identifiers) in R
# Variables are used to store data, and R allows dynamic assignment of types.

# Creating Variables
x = 10            # Using equal (=) operator
y <- 15           # Using leftward (<-) operator
a <- 30 
age <- 30 

# Naming Conventions for Variables in R
# Examples of naming conventions:
myname <- "John"              # alllowercase
new.name <- "Doe"             # period.separated
my_name <- "John_Doe"         # underscore_separated (standard)
myName <- "JohnDoe"           # lowerCamelCase
MyName <- "JohnDoe"           # UpperCamelCase

# Reserved Keywords in R
# Reserved words in R cannot be used as variable names.
?Reserved                   # List of reserved keywords in R

TRUE <- "Today is Friday"

