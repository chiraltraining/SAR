library(tidyverse)
library(readxl)

# read wide data 
wide_data <- readxl::read_excel("data/Life_Expectancy_Long.xlsx")
